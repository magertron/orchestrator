# Magertron Blog — branding update

Drop-in replacement for the Astro starter template files, restyled to match
magertron.com (dark theme, Inter/DM Sans/JetBrains Mono, blue accent).

## Files in this bundle

```
src/consts.ts                          ← replaces existing
src/styles/global.css                  ← replaces existing
src/components/BaseHead.astro          ← replaces existing
src/components/Header.astro            ← replaces existing
src/components/Footer.astro            ← replaces existing
src/pages/index.astro                  ← replaces existing
```

## Install steps

From your Codespace terminal:

```bash
cd /workspaces/magertron-mcpm/blog

# Back up the originals just in case
cp src/consts.ts                  src/consts.ts.bak
cp src/styles/global.css          src/styles/global.css.bak
cp src/components/BaseHead.astro  src/components/BaseHead.astro.bak
cp src/components/Header.astro    src/components/Header.astro.bak
cp src/components/Footer.astro    src/components/Footer.astro.bak
cp src/pages/index.astro          src/pages/index.astro.bak

# Then copy the new files from this bundle over the originals.
# (Or extract this zip directly into the blog/ directory — paths match.)

# Verify the build works locally before pushing
npm run build

# If build succeeds, commit and push
git add -A
git commit -m "Rebrand blog to match magertron.com (dark theme, Inter/DM Sans)"
git push
```

Cloudflare auto-rebuilds in ~30 seconds. Hard-refresh `https://blog.magertron.com/` or
test in incognito.

## What changed

- **Dark theme** matching magertron.com (`--bg: #06080c`, blue accent `#2563eb`)
- **Fonts**: Inter (headings), DM Sans (body), JetBrains Mono (code/logo)
- **Header**: fixed nav with "▸ magertron blog" wordmark, links to main site
- **Footer**: full five-column footer matching magertron.com structure
- **Home page**: hero with gradient text, latest-3 posts as cards, About Magertron
  showcase block, author byline section
- **Blog post pages** automatically inherit the new theme through global.css

## What did NOT change

The blog index (`/blog`) and individual post layouts (`BlogPost.astro`) still use
the Astro starter's structural patterns. They'll pick up the new colors and fonts
through `global.css`, but the layout structure is unchanged. If you want those
restyled to match the main site's showcase aesthetic, that's a follow-on update.

## Rollback

If something looks wrong:

```bash
cd /workspaces/magertron-mcpm/blog
for f in src/consts.ts src/styles/global.css src/components/BaseHead.astro \
         src/components/Header.astro src/components/Footer.astro src/pages/index.astro; do
  mv "$f.bak" "$f"
done
git checkout .
```
