# SVG banner — install

Replaces the placeholder hero image with a custom gradient banner matching
magertron.com's color palette. Four files to drop in.

## File mapping

```
public/blog-banner.svg                     ← new file
src/content/config.ts                      ← replaces existing
src/layouts/BlogPost.astro                 ← replaces existing
src/content/blog/we-are-ai-enabled.md      ← replaces existing (frontmatter change)
```

## Apply

From your Codespace, unzip this bundle into the blog directory — paths match:

```bash
cd /workspaces/magertron-mcpm/blog
unzip -o /path/to/svg-banner-update.zip -d /tmp/
cp -r /tmp/svg-banner-update/* .

# Sanity check
npm run build

# Commit
git add -A
git commit -m "Replace placeholder hero image with custom gradient banner"
git push
```

## What changed and why

1. **`public/blog-banner.svg`** — abstract gradient/glow banner in your brand
   palette (`#2563eb` blue, `#60a5fa` cyan, `#a78bfa` purple bloom, near-black
   `#06080c` base, faint grid texture). Lives in `public/` so it's served at
   the URL root: `/blog-banner.svg`.

2. **`src/content/config.ts`** — changed the heroImage schema from `image()`
   (which validates as a build-time imported asset and only accepts raster
   formats) to `z.string().optional()`, so it accepts a public-path URL like
   `/blog-banner.svg`. You're trading Astro's automatic image optimization for
   the ability to use SVG. For SVG that's fine — they're already vector and
   tiny.

3. **`src/layouts/BlogPost.astro`** — switched the `<Image>` component to a
   plain `<img>` (the `<Image>` component only works with imported assets, not
   URL strings) and added the banner-strip styling: 180px tall on desktop,
   120px on mobile, `object-fit: cover` so it crops cleanly.

4. **`src/content/blog/we-are-ai-enabled.md`** — frontmatter `heroImage`
   updated from `'../../assets/blog-placeholder-1.jpg'` (an asset path) to
   `'/blog-banner.svg'` (a public URL path). Also closed the trailing
   incomplete sentence at the end of the post — if you prefer the original,
   restore the last line manually.

## Going forward

Every new blog post can either:

- **Use the default banner**: `heroImage: '/blog-banner.svg'` in frontmatter
- **Use a custom banner**: drop the file in `public/` and reference it by
  its public path: `heroImage: '/custom-banner.svg'`
- **Skip the banner**: omit `heroImage` from frontmatter entirely (it's optional)

## Rollback

```bash
cd /workspaces/magertron-mcpm/blog
git checkout -- src/content/config.ts src/layouts/BlogPost.astro src/content/blog/we-are-ai-enabled.md
rm public/blog-banner.svg
```
